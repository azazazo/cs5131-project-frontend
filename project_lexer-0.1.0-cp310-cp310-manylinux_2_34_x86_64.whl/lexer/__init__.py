from .lexer import *

__doc__ = lexer.__doc__
if hasattr(lexer, "__all__"):
    __all__ = lexer.__all__